This directory contains the core shader files required for MGE XE rendering.

Core shader replacements can break on MGE XE upgrades.

Do not replace them! Use the core-mods directory.